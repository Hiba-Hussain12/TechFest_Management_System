-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2023 at 09:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `techfest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$ZNl1o81PSJct6C0zba6XDu6pO8HFZ4tn3e0O/SGeSc7At8Rkpedxa');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bid` int(10) NOT NULL,
  `pid` int(10) NOT NULL,
  `eid` int(10) NOT NULL,
  `is_approved` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bid`, `pid`, `eid`, `is_approved`) VALUES
(1, 1, 9, 0),
(2, 1, 6, 0),
(3, 1, 4, 0),
(4, 2, 3, 0),
(5, 2, 8, 0),
(6, 3, 2, 1),
(7, 3, 7, 0),
(8, 3, 1, 1),
(9, 1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `eid` int(10) NOT NULL,
  `eventname` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `fromtime` varchar(15) NOT NULL,
  `totime` varchar(15) NOT NULL,
  `venue` varchar(30) NOT NULL,
  `type` varchar(25) NOT NULL,
  `description` varchar(250) NOT NULL,
  `photo` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`eid`, `eventname`, `date`, `fromtime`, `totime`, `venue`, `type`, `description`, `photo`) VALUES
(1, 'Dig The Bug', '2023-12-01', '12:00', '12:30', 'CEC Lab 3', 'Competitions', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '1.jpg'),
(2, 'Autoshop', '2023-12-01', '09:30', '11:30', 'EC Block', 'Workshop', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2.jpg'),
(3, 'Web Development', '2023-12-02', '09:00', '13:30', 'Seminar Hall', 'Workshop', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', '3.jpg'),
(4, 'Tech Talk', '2023-12-01', '12:30', '13:15', 'Room 402', 'Others', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', '4.jpg'),
(5, 'VR', '2023-12-01', '15:30', '18:30', 'Campus', 'Others', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', '5.jpg'),
(6, 'Music Night', '2023-12-02', '21:00', '23:30', 'Campus', 'Others', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', '6.jpg'),
(7, 'Blind Coding', '2023-12-02', '12:30', '13:00', 'CS Lab1', 'Competitions', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', '7.jpg'),
(8, 'AI', '2023-12-01', '09:00', '11:00', 'Auditorium', 'Workshop', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', '8.jpg'),
(9, 'Quiz', '2023-12-02', '11:45', '12:45', 'Room 602', 'Competitions', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ', '9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `college` varchar(50) NOT NULL,
  `branch` varchar(10) NOT NULL,
  `year` int(11) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `name`, `email`, `contact`, `college`, `branch`, `year`, `password`) VALUES
(1, 'Sophia', 'sophia@gmail.com', 9013535343, 'College', 'CS', 3, '$2y$10$iYUPIcgU02Jb2JeZyTqzl.tzb3zjq2gDeJfY6uwpXWCtUFKT1Zml2'),
(2, 'Oliver', 'oliver@gmail.com', 7895647321, 'bcn', 'EEE', 2, '$2y$10$ZvwiIXBlM2yBPbB44AQSGOuPJjxYlo52zRK4Ns9YraH03FqmbpwJ2'),
(3, 'John', 'john@gmail.com', 7777777777, 'cec', 'CS', 3, '$2y$10$La7OSJ.9t0QJwIgJ0qWNDufWLfd/pNHB8zuaNQRspFx532i/Devi6'),
(4, 'Peter', 'peter@gmail.com', 8567567566, 'SS', 'CS', 1, '$2y$10$6ubtpWFC6BRRDFV52TeM1e5ga6SKATnV5.6ORgTxJPvR5atTyzwtu');

-- --------------------------------------------------------

--
-- Table structure for table `sponsors`
--

CREATE TABLE `sponsors` (
  `id` int(10) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `semail` varchar(30) NOT NULL,
  `scontact` bigint(10) NOT NULL,
  `photo` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sponsors`
--

INSERT INTO `sponsors` (`id`, `sname`, `semail`, `scontact`, `photo`) VALUES
(1, 'Asianet', 'asianet@gmail.com', 9673462102, 'asianet.png'),
(2, 'Red fm', 'redfm@gmail', 7563619520, 'redfm.png'),
(3, 'SBI', 'sbi@gmail.com', 8563292006, 'sbi.png'),
(4, 'Federal Bank', 'fb@gmail.com', 8537791002, 'federal_bank.png');

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int(10) NOT NULL,
  `vname` varchar(30) NOT NULL,
  `vemail` varchar(30) NOT NULL,
  `vcontact` varchar(10) NOT NULL,
  `vrole` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `volunteers`
--

INSERT INTO `volunteers` (`id`, `vname`, `vemail`, `vcontact`, `vrole`) VALUES
(1, 'Hima', 'hima@gmail.com', '8746371294', 'abcd'),
(2, 'Teena', 'teena@gmail.com', '7534782010', 'abcd'),
(3, 'Jordan', 'jordan@gmail.com', '7563910390', 'kdhej');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sponsors`
--
ALTER TABLE `sponsors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `eid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sponsors`
--
ALTER TABLE `sponsors`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
