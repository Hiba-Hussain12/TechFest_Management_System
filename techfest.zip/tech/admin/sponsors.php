<?php include 'includes/header.php'; ?>
<?php include 'includes/session.php'; ?>
<link rel="stylesheet" href="event.css" />
<section class="content">
  <nav>
    <i class="fas fa-bars menu-btn"></i>
    <h1>Sponsors</h1>
    </div>
    </form>
  </nav>
  <div class="addbutton">
    <a class='btn btn-add' href='/tech/admin/includes/sponsors-register.php'>Add</a>
  </div>
  <table class="table">
    <thead>
      <tr>
        <!-- <th class="table-header">ID</th> -->

        <th class="table-header">Id</th>
        <th class="table-header">Name</th>
        <th class="table-header">Email</th>

        <th class="table-header">Contact </th>
        <th class="table-header">Logo</th>

        <th class="table-header">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      include "includes/conn.php";
      $sql = "SELECT *, sponsors.id AS Sponsorid FROM sponsors";
      $result = $conn->query($sql);
      if (!$result) {
        die("Invalid query!");
      }
      while ($row = $result->fetch_assoc()) {
        $image = (!empty($row['photo'])) ? '../assets/images/' . $row['photo'] : '../assets/images/profile.jpg';
        echo "
                          <tr>
                          <td class='table-cell'>$row[id]</td>
                           
                            <td class='table-cell'>$row[sname]</td>
                            <td class='table-cell'>$row[semail]</td>    
                            <td class='table-cell'>$row[scontact]</td>  
                            <td class='table-cell'><img src='" . $image . "' width='50px' height='50px'></td> 
                            
                                                                                                                         
                              <td class='table-cell'>
                              <a class='btn btn-success' href='includes/sponsors-edit.php?id=" . $row['Sponsorid'] . "' onclick=\"return confirm('Are you sure you want to edit this item?')\">
                              <i class='fa-solid fa-pen-to-square'></i></a>
                              <a class='btn btn-danger' href='includes/sponsors-delete.php?id=" . $row['Sponsorid']. "'onclick=\"return confirm('Are you sure you want to delete this item?')\">
                              <i class='fa-solid fa-trash-can'></i></a>   
                                                
                            </td>
                          </tr>
                          ";
      }
      ?>
    </tbody>
  </table>
  </div>
  </div>
  </div>
  </div>

</section>

<script src="admin.js"></script>
</body>

</html>
