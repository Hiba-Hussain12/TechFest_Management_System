<?php include 'includes/header.php'; ?>
<?php include 'includes/session.php'; ?>

<section class="content">
  <nav>
    <i class="fas fa-bars menu-btn"></i>
    <h1>Dashboard</h1>
    </div>
    </form>
  </nav>

  <main>
    
    <div class="box-info">
      <li>
        <i class="fa-solid fa-user"></i>
        <span class="text">
          <h3>Total Registration</h3>
          <p>
            <?php
            $sql = "SELECT * FROM registration GROUP BY id";
            $querry = $conn->query($sql);
            echo "<h3>" . $querry->num_rows . "</h3>";
            ?>
          </p>
        </span>
      </li>
      <li>
        <i class="fas fa-people-group"></i>
        <span class="text">
          <h3>Total volunteers</h3>
          <p>
            <?php
            $sql = "SELECT * FROM volunteers GROUP BY id";
            $querry = $conn->query($sql);
            echo "<h3>" . $querry->num_rows . "</h3>";
            ?>
          </p>
        </span>
      </li>
      <li>
        <i class="fas fa-calendar"></i>
        <span class="text">
          <h3>Total Events</h3>
          <p>
            <?php
            $sql = "SELECT * FROM event GROUP BY eid";
            $querry = $conn->query($sql);
            echo "<h3>" . $querry->num_rows . "</h3>";
            ?>
          </p>
        </span>
      </li>
    </div>
  </main>
</section>

<script src="admin.js"></script>
</body>

</html>