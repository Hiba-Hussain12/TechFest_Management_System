<?php include 'includes/header.php'; ?>
<?php include 'includes/session.php'; ?>
<link rel="stylesheet" href="event.css" />
<section class="content">
  <nav>
    <i class="fas fa-bars menu-btn"></i>
    <h1>Volunteers</h1>
    </div>
    </form>
  </nav>
  <div class="addbutton">
    <a class='btn btn-add' href='/tech/admin/includes/volunteers-register.php'>Add</a>
  </div>
  <table class="table">
    <thead>
      <tr>
        <!-- <th class="table-header">ID</th> -->

        <th class="table-header">Slno</th>
        <th class="table-header">Name</th>
        <th class="table-header">Email</th>

        <th class="table-header">Contact </th>
        <th class="table-header">Role</th>

        <th class="table-header">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      include "includes/conn.php";
      $sql = "SELECT *, volunteers.id AS Volunteersid FROM volunteers";
      $result = $conn->query($sql);
      if (!$result) {
        die("Invalid query!");
      }
      while ($row = $result->fetch_assoc()) {
    
        echo "
                          <tr>
                          <td class='table-cell'>$row[id]</td>
                           
                            <td class='table-cell'>$row[vname]</td>
                            <td class='table-cell'>$row[vemail]</td>    
                            <td class='table-cell'>$row[vcontact]</td>  
                            <td class='table-cell'>$row[vrole]</td>  
                             
                            
                                                                                                                         
                              <td class='table-cell'>
                              <a class='btn btn-success' href='includes/volunteers-edit.php?id=" . $row['Volunteersid'] . "' onclick=\"return confirm('Are you sure you want to edit this item?')\">
                              <i class='fa-solid fa-pen-to-square'></i></a>
                              <a class='btn btn-danger' href='includes/volunteers-delete.php?id=" . $row['Volunteersid']. "'onclick=\"return confirm('Are you sure you want to delete this item?')\">
                              <i class='fa-solid fa-trash-can'></i></a>   
                                                
                            </td>
                          </tr>
                          ";
      }
      ?>
    </tbody>
  </table>
  </div>
  </div>
  </div>
  </div>

</section>

<script src="admin.js"></script>
</body>

</html>
