<?php include 'includes/header.php'; ?>

<?php include 'includes/eventtop.php';?>

<?php include "includes/conn.php";
                        $sql = "SELECT *, event.eid AS Eventid FROM event where type='competitions'";
                        ?>
                        
<?php include 'includes/eventdown.php';?>




                        