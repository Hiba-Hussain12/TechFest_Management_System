<?php
if (isset($_POST['submit'])) {
    $edit_eid = $_POST['edit_eid'];
    $eventname = $_POST['eventname'];
    $date = $_POST['Date'];
    $fromtime = $_POST['fromtime'];
    $totime = $_POST['totime'];
    $venue = $_POST['venue'];
    $type = $_POST['type'];
    $description = $_POST['description'];

    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "techfest");

    if (!$conn) {
        die('Could not connect: ' . mysqli_connect_error());
    }

    // Check if a new photo is uploaded
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $filename = $_FILES['photo']['name'];
        move_uploaded_file($_FILES['photo']['tmp_name'], '/xampp/htdocs/tech/assets/images/' . $filename);
        // Update the record with the new photo
        $sql = "UPDATE event SET eventname = ?, date = ?, fromtime=?, totime=?, venue=?, type=?, description=?, photo = ? WHERE eid = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die('Error preparing statement: ' . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "ssssssssi", $eventname, $date, $fromtime, $totime, $venue, $type, $description, $filename, $edit_eid);
    } else {
        // Update the record without changing the existing photo
        $sql = "UPDATE event SET eventname = ?, date = ?, fromtime=?, totime=?, venue=?, type=?, description=? WHERE eid = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die('Error preparing statement: ' . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "sssssssi", $eventname, $date, $fromtime, $totime, $venue, $type, $description, $edit_eid);
    }

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        echo "Record updated successfully.";
        header('location: /tech/admin/event.php');
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    // Close the statement and connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    echo "Invalid request. Please submit the form.";
}
?>
