<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/eventregister.css">
    <title>Sponsor Registration</title>
</head>
<body>
<div class="eventregister">
        
        <div class="eventregister-box">
          
            <div class="eventregister-left">
                <h1>Sponsor Registration</h1>
                <form action="sponsors-register.php"method="post" enctype="multipart/form-data">
                   
                    <div class="eventregisterinput-row">
                        <div class="eventregisterinput-group">
                            <label> Name</label>
                            <input type="text"name="sname"placeholder="Sponsorname"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Email</label>
                            <input type="email"name="semail"placeholder="email"required>
                        </div>
                    </div>
                    <div class="eventregisterinput-row">
                        <div class="eventregisterinput-group">
                            <label>Contact </label>
                            <input type="text"name="scontact"placeholder="phone"title="Error Message"pattern="[1-9]{1}[0-9]{9}"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Logo </label>
                        <input type="file" id="photo" name="photo">
                    </div>
                    </div> 
                    <div class="eventregisterbutton">           
                    <button type="submit" class="btn" name='submit' value="Save">Save</button>
                    <button type="button" class="btnz" name="cancel" value="cancel" onclick="window.location.href='../sponsors.php'">Cancel</button>
                    </div>
                </form>

            </div>
            <div class="eventregister-right">

            </div>
        </div>
    </div>
</body>

</html>
<?php
if (isset($_POST['submit'])) {
    $sname = $_POST['sname'];
    $semail= $_POST['semail'];
    $scontact = $_POST['scontact'];
    $filename = $_FILES['photo']['name'];

    if (!empty($filename)) {
        move_uploaded_file($_FILES['photo']['tmp_name'], '/xampp/htdocs/tech/assets/images/' . $filename);
    }

    $conn = mysqli_connect("localhost", "root", "", "techfest");
    if (!$conn) {
        die('could not connect' . mysqli_connect_error());
    }
    $sql = "INSERT INTO sponsors(sname,semail,scontact,photo) VALUES ('$sname', '$semail','$scontact','$filename')";

    if (!mysqli_query($conn, $sql)) {
        die('Error:' . mysqli_error($conn));
    }
    echo '<script>';

    echo 'alert("one record inserted successfully");';
    echo 'window.location.href="../sponsors.php";';
    echo '</script>';
    mysqli_close($conn);
}

?>