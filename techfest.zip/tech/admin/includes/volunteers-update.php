<?php
// update.php

if (isset($_POST['submit'])) {
    $edit_id = $_POST['edit_id'];
    $vname = $_POST['vname'];
    $vemail = $_POST['vemail'];
    $vcontact = $_POST['vcontact'];
    $vrole = $_POST['vrole'];
    
   
    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "techfest");

    if (!$conn) {
        die('Could not connect: ' . mysqli_connect_error());
    }

    
    
    
    
    $sql = "UPDATE volunteers SET vname = ?, vemail = ?,vcontact=?,vrole=? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssssi", $vname, $vemail,$vcontact,$vrole,$edit_id);
    

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        echo "Record updated successfully.";
        header('location: \tech\admin\volunteers.php');
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    // Close the statement and connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    echo "Invalid request. Please submit the form.";
}
