<?php
// approve.php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Include your database connection file
    include "conn.php";
    if (!$conn) {
        die('Could not connect: ' . mysqli_connect_error());
    }

    // Check if approvedParticipants array is set in the POST data
    if (isset($_POST['approvedParticipants']) && is_array($_POST['approvedParticipants'])) {
        foreach ($_POST['approvedParticipants'] as $bookingId) {
            // Update the 'approved' column in the booking table
            // Update the is_approved column in the booking table
            $updateSql = "UPDATE booking SET is_approved = 1 WHERE bid = $bookingId";

           //updateSql = "UPDATE booking SET approved = 1 WHERE bid = $bookingId";
            $updateResult = $conn->query($updateSql);

            // Handle the update result (you can add additional error handling)
            if ($updateResult) {
                echo "Participant with Booking ID $bookingId has been approved.<br>";
            } else {
                echo "Error approving participant with Booking ID $bookingId.<br>";
            }
        }
    } else {
        echo "No participants selected for approval.<br>";
    }

    // Close the database connection
    $conn->close();
} else {
    // Handle the case where the script is accessed directly without a POST request
    echo "Invalid access to approve.php.";
}
?>
