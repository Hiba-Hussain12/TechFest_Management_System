<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/eventregister.css">
    <title>EVENT REGISTER</title>
</head>
<body>
<div class="eventregister">
        
        <div class="eventregister-box">
          
            <div class="eventregister-left">
                <h1>Event Registration</h1>
                <form action="eventregister.php" method="post" enctype="multipart/form-data">
                   
                    <div class="eventregisterinput-row">
                        <div class="eventregisterinput-group">
                            <label>Event Name</label>
                            <input type="text"name="eventname"placeholder="Event name"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Date</label>
                            <input type="Date"name="Date"placeholder="YYYY-MM-DD"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>From Time</label>
                            <input type="time"name="fromtime"placeholder="HH:MM:SS"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>To Time</label>
                            <input type="time"name="totime"placeholder="HH:MM:SS"required>
                        </div>
                    </div>
                    <div class="eventregisterinput-row">
                        <div class="eventregisterinput-group">
                            <label>Venue </label>
                            <input type="text"name="venue"placeholder="Venue"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Event Poster </label>
                        <input type="file" id="photo" name="photo"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Type </label>
                            <select name="type"required>
                                <option value="">choose option</option>
                                <option value="Workshop">Workshop</option>
                                <option value="Competitions">competitions</option>
                                <option value="Others">Other event</option>
                            </select>

                        </div>
                       
                    </div> 
                    <label>Description</label>
                    <textarea  rows="5"name="description"placeholder="Description of event"required maxlength="250"></textarea>
                    <div class="eventregisterbutton">           
                    <button type="submit" class="btn" name='submit' value="Save">Register</button>
                    <button type="button" class="btnz" name="cancel" value="cancel" onclick="window.location.href='../event.php'">Cancel</button>
                    </div>
                </form>

            </div>
            <div class="eventregister-right">

            </div>
        </div>
    </div>
</body>

</html>
<?php
if (isset($_POST['submit'])) {
    $eventname = $_POST['eventname'];
    $date = $_POST['Date'];
    $fromtime = $_POST['fromtime'];
    $totime = $_POST['totime'];
    $venue = $_POST['venue'];
    $type = $_POST['type'];
    $description = $_POST['description'];
    $filename = $_FILES['photo']['name'];

    if (!empty($filename)) {
        move_uploaded_file($_FILES['photo']['tmp_name'], '/xampp/htdocs/tech/assets/images/' . $filename);
    }

    $conn = mysqli_connect("localhost", "root", "", "techfest");
    if (!$conn) {
        die('could not connect' . mysqli_connect_error());
    }
    $sql = "INSERT INTO event(eventname, date,fromtime,totime,venue,type,description,photo) VALUES ('$eventname', '$date','$fromtime','$totime','$venue','$type','$description','$filename')";

    if (!mysqli_query($conn, $sql)) {
        die('Error:' . mysqli_error($conn));
    }
    echo '<script>';

    echo 'alert("one record inserted successfully");';
    echo 'window.location.href="../event.php";';
    echo '</script>';
    mysqli_close($conn);
}

?>