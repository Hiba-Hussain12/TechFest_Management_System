<link rel="stylesheet" href="event.css"/>

<section class="content">
      <nav>
        <i class="fas fa-bars menu-btn"></i>
        <h1>Event</h1>
          </div>
        </form>
       </nav>
      
                
                 
                                                            
                 <div class="eventbutton">    
                    <ul>             
                 <li><a  href='/tech/admin/event.php'>All</a> </li>                        
               
                 <!-- <div class="addbutton">                   -->
                <li> <a  href='/tech/admin/event-workshop.php'>workshop</a> </li>                                  
                <!-- </div> -->
                <!-- <div class="addbutton">                   -->
                <li><a  href='/tech/admin/event-competitions.php'>Competitions</a></li>                                 
                <!-- </div> -->
                <!-- <div class="addbutton">                   -->
                <li><a  href='/tech/admin/event-others.php'>Other Event</a></li>                                 
                <!-- </div> -->
                      
              </ul>                            
                </div>
                <div class="addbutton">                  
                <a href='/tech/admin/includes/eventregister.php'>Create +</a>
                </div>
                    <table class="table">
                      <thead>
                        <tr>
                          <!-- <th class="table-header">ID</th> -->

                          <th class="table-header">Id</th>
                          <th class="table-header">Photo</th>
                          <th class="table-header">Event Name</th>
                    
                          <th class="table-header">Date </th> 
                          <th class="table-header">From Time </th> 
                          <th class="table-header">To Time </th>
                          <th class="table-header">Venue</th>            
                                     

                                    
                          <th class="table-header">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
         