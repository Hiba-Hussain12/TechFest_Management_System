<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/eventregister.css">
    <title>Volunteers Registration</title>
</head>
<body>
<div class="eventregister">
        
        <div class="eventregister-box">
          
            <div class="eventregister-left">
                <h1>Volunteers Registration</h1>
                <form action="volunteers-register.php"method="post" enctype="multipart/form-data">
                   
                    <div class="eventregisterinput-row">
                        <div class="eventregisterinput-group">
                            <label> Name</label>
                            <input type="text"name="vname"placeholder="Volunteer name"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Email</label>
                            <input type="email"name="vemail"placeholder="email"required>
                        </div>
                    </div>
                    <div class="eventregisterinput-row">
                        <div class="eventregisterinput-group">
                            <label>Contact </label>
                            <input type="text"name="vcontact"placeholder="phone"title="Error Message"pattern="[1-9]{1}[0-9]{9}"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Role</label>
                            <input type="text"name="vrole"placeholder="Roles"required>
                        </div>
             </div> 
                    <div class="eventregisterbutton">           
                    <button type="submit" class="btn" name='submit' value="Save">Save</button>
                    <button type="button" class="btnz" name="cancel" value="cancel" onclick="window.location.href='../volunteers.php'">Cancel</button>
                    </div>
                </form>

            </div>
            <div class="eventregister-right">

            </div>
        </div>
    </div>
</body>

</html>
<?php
if (isset($_POST['submit'])) {
    $vname = $_POST['vname'];
    $vemail= $_POST['vemail'];
    $vcontact = $_POST['vcontact'];
    $vrole = $_POST['vrole'];
    

   

    $conn = mysqli_connect("localhost", "root", "", "techfest");
    if (!$conn) {
        die('could not connect' . mysqli_connect_error());
    }
    $sql = "INSERT INTO volunteers(vname,vemail,vcontact,vrole) VALUES ('$vname', '$vemail','$vcontact','$vrole')";

    if (!mysqli_query($conn, $sql)) {
        die('Error:' . mysqli_error($conn));
    }
    echo '<script>';

    echo 'alert("one record inserted successfully");';
    echo 'window.location.href="../volunteers.php";';
    echo '</script>';
    mysqli_close($conn);
}

?>