<?php
if (isset($_GET['id'])) {
    // Get the ID from the URL parameter
    $delete_id = $_GET['id'];

    //database connection
    $conn = mysqli_connect("localhost", "root", "", "techfest");

    if (!$conn) {
        die('Could not connect: ' . mysqli_connect_error());
    }

    // Construct the SQL query to delete the row
    $sql = "DELETE FROM event WHERE eid = ?";

    // Use prepared statements for security
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $delete_id);

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        echo "Row deleted successfully.";
        header('location: \tech\admin\event.php');
    } else {
        echo "Error deleting row: " . mysqli_error($conn);
    }

    // Close the statement and connection
    mysqli_stmt_close($stmt);
    $sql_reset_auto_increment = "ALTER TABLE event AUTO_INCREMENT = 1";
$conn->query($sql_reset_auto_increment);
mysqli_close($conn);


} else {
    echo "Invalid request. Please provide an ID to delete.";
}
