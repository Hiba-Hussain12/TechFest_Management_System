<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Panel</title>

    <!--font awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>

    <!--css file-->
    <link rel="stylesheet" href="admin.css"/>

  </head>
  <body>
    <section class="sidebar">
      <a class="logo">
        <i class="fa-solid fa-shield"></i>    
        <span class="text">Admin Panel</span>
      </a>

      <ul class="side-menu top">
        <li class="active">
          <a href="dashboard.php" class="nav-link">
            <i class="fas fa-border-all"></i>
            <span class="text">Dashboard</span>
          </a>
        </li>
        <li class="active">
          <a href="event.php" class="nav-link">
            <i class="fa-solid fa-calendar-days"></i>
            <span class="text">Event</span>
          </a>
        </li>
        <li class="active">
          <a href="registration.php" class="nav-link">
            <i class="fa-solid fa-user"></i>
            <span class="text">Registrations</span>
          </a>
        </li>
        <li class="active">
          <a href="participants.php" class="nav-link">
            <i class="fa-solid fa-user"></i>
            <span class="text">Participants</span>
          </a>
        </li>
        <li class="active">
          <a href="volunteers.php" class="nav-link">
            <i class="fa-sharp fa-solid fa-people-group"></i>
            <span class="text">Volunteers</span>
          </a>
        </li>
        
        <li class="active">
          <a href="sponsors.php" class="nav-link">
            <i class="fa-solid fa-handshake-angle"></i>
            <span class="text">Sponsors</span>
          </a>
        </li>
       </ul>

      <ul class="side-menu">
        <li class="active">
           <span class="text"><a href="logout.php"><i class="fas fa-right-from-bracket"></i></a></span>
          </a>
        </li>
      </ul>
    </section>
    