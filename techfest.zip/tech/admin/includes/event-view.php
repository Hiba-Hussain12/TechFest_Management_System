<!-- event-view.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Details</title>
    <link rel="stylesheet" href="event-view.css">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            color: #fff;
        }

        th {
            background-color: fff;
        }

        .approve-form {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<?php
// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $viewid = $_GET['id'];

    // Include your database connection file
    include "conn.php";
    if (!$conn) {
        die('Could not connect: ' . mysqli_connect_error());
    }

    // Fetch the event details from the database based on the provided ID
    $sql = "SELECT * FROM event WHERE eid = $viewid";
    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        $fromtime12hr = date('h:i A', strtotime($row['fromtime']));
        $totime12hr = date('h:i A', strtotime($row['totime']));
        $formattedDate = date('d-m-Y', strtotime($row['date']));
        $image = (!empty($row['photo'])) ? '../../assets/images/' . $row['photo'] : '../../assets/images/profile.jpg';

        // Display the event details
        echo "
            <div class='container'>
                <div class='image-container'>
                    <img src='$image'>
                </div>
                <div class='content-container'>
                    <h1>$row[eventname]</h1>
                    <h5>Date: $formattedDate </h5>
                    <h5>From: $fromtime12hr </h5>
                    <h5>To: $totime12hr </h5>
                    <h5>Venue: $row[venue] </h5>
                    <p>Description:$row[description] </p>
                </div>
            </div>
        ";

        // Display the participant details table
        $participantSql = "SELECT registration.name AS participant, 
            registration.contact AS contact, 
            registration.branch AS branch,
            registration.year AS year,
            booking.bid AS booking_id
            FROM booking
            JOIN registration ON registration.id = booking.pid
            JOIN event ON event.eid = booking.eid
            WHERE event.eid = $viewid";
        $participantResult = $conn->query($participantSql);

        echo "
            <form action='approve.php' method='post' class='approve-form'>
                <table>
                    <thead>
                        <tr>
                            <th>Slno</th>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Branch</th>
                            <th>Year</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
        ";

        $slno = 1;
        while ($participantRow = $participantResult->fetch_assoc()) {
            echo "
                <tr>
                    <td>$slno</td>
                    <td>{$participantRow['participant']}</td>
                    <td>{$participantRow['contact']}</td>
                    <td>{$participantRow['branch']}</td>
                    <td>{$participantRow['year']}</td>
                    <td>
                   
                         <input type='checkbox' name='approvedParticipants[]' value='{$participantRow['booking_id']}'>
                        Approve<button type='submit'' onclick=\"return confirm('Are you sure you want to Approve certificate?')\">Submit</button>
                    </td>
                </tr>
            ";
            $slno++;
        }

        echo "
                    </tbody>
                </table>
                
            </form>
        ";
    }
}

?>

</body>
</html>
