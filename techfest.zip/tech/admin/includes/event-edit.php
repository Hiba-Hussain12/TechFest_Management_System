<?php
// edit.php

if (isset($_GET['id'])) {
    $edit_eid = $_GET['id'];

    //database connection
    $conn = mysqli_connect("localhost", "root", "", "techfest");

    if (!$conn) {
        die('Could not connect: ' . mysqli_connect_error());
    }

    //existing data for the record to be edited
    $sql = "SELECT * FROM event WHERE eid = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $edit_eid);
    mysqli_stmt_execute($stmt);

    // Fetch the result
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    // Close the statement
    mysqli_stmt_close($stmt);

    // Close the database connection
    mysqli_close($conn);

    if ($row) {
        // Display the edit form with the existing data
?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
            <link rel="stylesheet" href="../css/eventregister.css">
            <title>EVENT REGISTER</title>
        </head>

        <body>
            <div class="eventregister">

                <div class="eventregister-box">

                    <div class="eventregister-left">
                        <h1>Event Registration</h1>
                        <form action="event-update.php" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="edit_eid" value="<?php echo $row['eid']; ?>">
                            <div class="eventregisterinput-row">
                                <div class="eventregisterinput-group">
                                    <label>Event Name</label>
                                    <input type="text" name="eventname" placeholder="Event name" value="<?php echo $row['eventname']; ?>" required>
                                </div>
                                <div class="eventregisterinput-group">
                                    <label>Date</label>
                                    <input type="Date" name="Date" placeholder="YYYY-MM-DD" value="<?php echo $row['date']; ?>" required>
                                </div>
                                <div class="eventregisterinput-group">
                                    <label>From Time</label>
                                    <input type="time" name="fromtime" placeholder="HH:MM:SS" value="<?php echo $row['fromtime']; ?>" required>
                                </div>
                                <div class="eventregisterinput-group">
                                    <label>To Time</label>
                                    <input type="time" name="totime" placeholder="HH:MM:SS" value="<?php echo $row['totime']; ?>" required>
                                </div>
                            </div>
                            <div class="eventregisterinput-row">
                                <div class="eventregisterinput-group">
                                    <label>Venue </label>
                                    <input type="text" name="venue" placeholder="Venue" value="<?php echo $row['venue']; ?>" required>
                                </div>
                                <div class="eventregisterinput-group">
                                    <label>Event Poster </label>
                                    <input type="file" id="photo" name="photo">
                                </div>
                                <div class="eventregisterinput-group">
                                    <label>Type </label>
                                    <select name="type" value="<?php echo $row['type']; ?>"required>
                                        <option value="">choose option</option>
                                        <option value="Workshop">Workshop</option>
                                        <option value="Competitions">Competitions</option>
                                        <option value="Others">Other event</option>
                                    </select>

                                </div>
                            </div>
                            <label>Description</label>
                            <textarea rows="5" name="description" placeholder="Description of event" value="<?php echo $row['description']; ?>" required maxlength="250"></textarea>
                            <div class="eventregisterbutton">
                                <button type="submit" class="btn" name='submit' value="Save">Register</button>
                                <button type="button" class="btnz" name="cancel" value="cancel" onclick="window.location.href='../event.php'">Cancel</button>
                            </div>
                        </form>

                    </div>
                    <div class="eventregister-right">

                    </div>
                </div>
            </div>
        </body>

        </html>
<?php
    } else {
        echo "Record not found.";
    }
} else {
    echo "Invalid request. Please provide an ID to edit.";
}

?>