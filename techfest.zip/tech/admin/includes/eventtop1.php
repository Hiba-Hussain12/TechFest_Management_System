<link rel="stylesheet" href="event.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<section class="content">
      <nav>
        <i class="fas fa-bars menu-btn"></i>
        <h1>Event</h1>
          </div>
        </form>
       </nav>
       <!-- <div class="home-content">
        <div class="sales-boxes">
            <div class="recent-sales box">
                
                                                                 -->
                                                            
                 <div class="eventbutton">    
                    <ul>              
                 <li><a  href='/tech/admin/event.php'>All</a> </li>                        
               
                 <!-- <div class="addbutton">                   -->
                <li> <a href='/tech/admin/event-workshop.php'>Workshop</a> </li>                                  
                <!-- </div> -->
                <!-- <div class="addbutton">                   -->
                <li><a  href='/tech/admin/event-competitions.php'>Competitions</a></li>                                 
                <!-- </div> -->
                <!-- <div class="addbutton">                   -->
                <li><a  href='/tech/admin/event-others.php'>Other Event</a></li>                                 
                <!-- </div> -->
                      
              </ul>                            
                </div>
                <div class="addbutton">                  
                <a href='/tech/admin/includes/eventregister.php'>Create +</a>
                </div>
                    <table class="table">
                      <thead>
                        <tr>
                          <!-- <th class="table-header">ID</th> -->

                          <th class="table-header">Sl.no</th>
                          <th class="table-header">Photo</th>
                          <th class="table-header">Event Name</th>
                    
                          <th class="table-header">Date </th> 
                          <th class="table-header">From Time </th> 
                          <th class="table-header">To Time </th>
                          <th class="table-header">Venue</th>            
                                     

                          <th class="table-header">Type</th>            
                                    
                          <th class="table-header">Actions</th>

                        </tr>
                      </thead>
                      <tbody>
         