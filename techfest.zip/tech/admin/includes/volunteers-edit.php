<?php
// edit.php

if (isset($_GET['id'])) {
    $edit_id = $_GET['id'];

    //database connection
    $conn = mysqli_connect("localhost", "root", "", "techfest");

    if (!$conn) {
        die('Could not connect: ' . mysqli_connect_error());
    }

    //existing data for the record to be edited
    $sql = "SELECT * FROM volunteers WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $edit_id);
    mysqli_stmt_execute($stmt);

    // Fetch the result
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    // Close the statement
    mysqli_stmt_close($stmt);

    // Close the database connection
    mysqli_close($conn);

    if ($row) {
        // Display the edit form with the existing data
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/eventregister.css">
    <title>Volunteers Edit</title>
</head>
<body>
<div class="eventregister">
        
        <div class="eventregister-box">
          
            <div class="eventregister-left">
                <h1>Edit Volunteers Registration</h1>
                <form action="volunteers-update.php"method="post" enctype="multipart/form-data">
                <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
                    <div class="eventregisterinput-row">
                        <div class="eventregisterinput-group">
                            <label>Name</label>
                            <input type="text"name="vname"placeholder="Volunteers name"value="<?php echo $row['vname']; ?>"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Email</label>
                            <input type="email"name="vemail"placeholder="email"value="<?php echo $row['vemail']; ?>"required>
                        </div>
                    </div>
                    <div class="eventregisterinput-row">
                        <div class="eventregisterinput-group">
                            <label>Contact Number</label>
                            <input type="text"name="vcontact"placeholder="phone"value="<?php echo $row['vcontact']; ?>"title="Error Message"pattern="[1-9]{1}[0-9]{9}"required>
                        </div>
                        <div class="eventregisterinput-group">
                            <label>Role</label>
                            <input type="text"name="vrole"placeholder="role"value="<?php echo $row['vrole']; ?>"required>
                        </div>
                      
                    </div> 
                                        <div class="eventregisterbutton">           
                    <button type="submit" class="btn" name='submit' value="Save">Register</button>
                    <button type="button" class="btnz" name="cancel" value="cancel" onclick="window.location.href='../volunteers.php'">Cancel</button>
                    </div>
                </form>

            </div>
            <div class="eventregister-right">

            </div>
        </div>
    </div>
</body>

</html>
<?php
    } else {
        echo "Record not found.";
    }
} else {
    echo "Invalid request. Please provide an ID to edit.";
}

?>