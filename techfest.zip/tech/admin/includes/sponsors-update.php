<?php
// update.php

if (isset($_POST['submit'])) {
    $edit_id = $_POST['edit_id'];
    $sname = $_POST['sname'];
    $semail = $_POST['semail'];
    $scontact = $_POST['scontact'];
    
   
    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "techfest");

    if (!$conn) {
        die('Could not connect: ' . mysqli_connect_error());
    }

    // Check if a new photo is uploaded
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $filename = $_FILES['photo']['name'];
        move_uploaded_file($_FILES['photo']['tmp_name'], '/xampp/htdocs/tech/assets/images/' . $filename);

        // Update the record with the new photo
        $sql = "UPDATE sponsors SET sname = ?, semail= ?,scontact=?, photo = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssssi", $sname, $semail,$scontact,$filename, $edit_id);
    } else {
        // Update the record without changing the existing photo
        $sql = "UPDATE sponsors SET sname = ?, semail = ?,scontact=? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssi", $sname, $semail,$scontact,$edit_id);
    }

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        echo "Record updated successfully.";
        header('location: \tech\admin\sponsors.php');
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    // Close the statement and connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    echo "Invalid request. Please submit the form.";
}
