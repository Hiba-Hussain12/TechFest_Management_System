<?php


$conn = new mysqli('localhost','root','','techfest');
if($conn->connect_error){
	die("Connection failed".$conn->connect_error);

}
echo"";


?>