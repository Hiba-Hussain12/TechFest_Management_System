<?php include 'includes/header.php'; ?>
<?php include 'includes/session.php'; ?>
<link rel="stylesheet" href="event.css" />
<section class="content">
  <nav>
    <i class="fas fa-bars menu-btn"></i>
    <h1>Registrations</h1>
    </div>
    </form>
  </nav>
  <table class="table">
    <thead>
      <tr>
        <th class="table-header">Slno</th>
        <th class="table-header">Name</th>
        <th class="table-header">Email</th>

        <th class="table-header">Contact </th>
        <th class="table-header">Branch</th>

        <th class="table-header">Year</th>
      </tr>
    </thead>
    <tbody>
      <?php
      include "includes/conn.php";
      $sql = "SELECT * FROM registration";
      $result = $conn->query($sql);
      if (!$result) {
        die("Invalid query!");
      }
      while ($row = $result->fetch_assoc()) {

        echo "
                          <tr>
                          <td class='table-cell'>$row[id]</td>
                           
                            <td class='table-cell'>$row[name]</td>
                            <td class='table-cell'>$row[email]</td>    
                            <td class='table-cell'>$row[contact]</td>  
                            <td class='table-cell'>$row[branch]</td>  
                            <td class='table-cell'>$row[year]</td>  
                            
                            
                                                                                                                         
                         
                                                   
                            </td>
                          </tr>
                          ";
      }
      ?>
    </tbody>
  </table>
  </div>
  </div>
  </div>
  </div>


</section>

<script src="admin.js"></script>
</body>

</html>



