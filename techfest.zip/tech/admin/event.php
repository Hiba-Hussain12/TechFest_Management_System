<?php include 'includes/header.php'; ?>
<?php include 'includes/session.php'; ?>
<?php include 'includes/eventtop1.php';?>
<?php include "includes/conn.php";
                        $sql = "SELECT * FROM event";
                        $result = $conn->query($sql);

if (!$result) {
  die("Invalid query!");
}
if ($result->num_rows > 0) {
  $rowNumber = 1;
while ($row = $result->fetch_assoc()) {
  $fromtime12hr = date('h:i A', strtotime($row['fromtime']));
  $totime12hr = date('h:i A', strtotime($row['totime']));
  $formattedDate = date('d-m-Y', strtotime($row['date']));
$image = (!empty($row['photo'])) ? '../assets/images/'.$row['photo'] : '../assets/images/profile.jpg';
  echo "

  <tr>
  <td class='table-cell'>$rowNumber</td>
  <td class='table-cell'><img src='".$image."' width='50px' height='50px'></td>  
    <td class='table-cell'>$row[eventname]</td>
    <td class='table-cell datecell'>$formattedDate</td>  
    <td class='table-cell'>$fromtime12hr</td>  
    <td class='table-cell'>$totime12hr</td>  
    <td class='table-cell'>$row[venue]</td>  
    <td class='table-cell'>$row[type]</td>  
                                                                                                 
      <td class='table-cell'>
      <a class='btn btn-info' href='includes/event-view.php?id=" . $row['eid'] . "'><i class='fa-solid fa-eye'></i></a>
      <a class='btn btn-success' href='includes/event-edit.php?id=" . $row['eid'] . "' onclick=\"return confirm('Are you sure you want to edit this item?')\">
      <i class='fa-solid fa-pen-to-square'></i></a>
          <a class='btn btn-danger' href='includes/event-delete.php?id=".$row['eid']."'onclick=\"return confirm('Are you sure you want to delete this item?')\">
          <i class='fa-solid fa-trash-can'></i></a>                       
    </td>
  </tr>
  ";
                      $rowNumber++; 
                    }  
                    }
?>




</tbody>
</table>
</div>   
</div>
</div>
</div>
</section>
  <script src="admin.js"></script>
</body>
</html>


                        

