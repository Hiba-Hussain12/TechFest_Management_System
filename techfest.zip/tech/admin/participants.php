<?php include 'includes/header.php'; ?>
<?php include 'includes/session.php'; ?>
<link rel="stylesheet" href="event.css"/>
<section class="content">
  <nav>
    <i class="fas fa-bars menu-btn"></i>
    <h1>Registrations</h1>
    </div>
    </form>
  </nav>
  <table class="table">
    <thead>
      <tr>
        <th class="table-header">Slno</th>
        <th class="table-header">Name</th>
        <th class="table-header">Contact </th>
        <th class="table-header">Branch</th>
        <th class="table-header">Year</th>
        <th class="table-header">Event</th>
      </tr>
    </thead>
    <tbody>
    <?php
include "includes/conn.php";

$sql = "SELECT registration.name AS participant, 
               registration.contact as contact, 
               registration.branch as branch,
               registration.year as year,
               GROUP_CONCAT(event.eventname) AS bookedevents
        FROM booking
        JOIN registration ON registration.id = booking.pid
        JOIN event ON event.eid = booking.eid
        GROUP BY registration.name";

$query = $conn->query($sql);

if ($query->num_rows > 0) {
  $rowNumber = 1;
  if ($query)  {
    while ($row = $query->fetch_assoc()) {
        echo "
            <tr>
                <td class='table-cell'>$rowNumber</td>
                <td class='table-cell'>" . $row['participant'] . "</td>
                <td class='table-cell'>" . $row['contact'] . "</td>
                <td class='table-cell'>" . $row['branch'] . "</td>
                <td class='table-cell'>" . $row['year'] . "</td>
                <td class='table-cell'>" . $row['bookedevents'] . "</td>
            </tr>
        ";
        $rowNumber++; 
    }
    }
} else {
    echo " " . $conn->error;
}

$conn->close();



?>

     

</tbody>
  </table>
  </div>
  </div>
  </div>
  </div>


</section>

<script src="admin.js"></script>
</body>

</html>
