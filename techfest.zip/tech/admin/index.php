<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login To Techfest </title>
    <link rel="stylesheet" href="loginstyle.css">
    <script src="https://kit.fontawesome.com/1d8b9d565e.js"></script>
</head>
<?php
session_start();
if (isset($_SESSION['admin'])) {
    header('location:dashboard.php');
}
?>
<div class="container">
    <div class="image"></div>
    <div class="form-box">
        <h1 id="title">Admin</h1>
        <form action="login.php" method="POST">
            <div class="input-group">
                <div class="input-field">
                    <i class="fas fa-user"></i>
                    <input type="text" class="form-control" name="username" placeholder="Username" required>
                </div>
                <div class="input-field">
                    <i class="fas fa-lock"></i>
                    <input type="password" class="form-control" name="password" placeholder="Password" required>
                </div>

                <div class="btn-field">
                    <button type="submit" class="signinBtn" name="login">Sign In</button>
                </div>
            </div>
        </form>
    </div>
    <?php
    if (isset($_SESSION['error'])) {
        echo "
  				<div class='callout callout-danger text-center mt20'>
			  		<p>" . $_SESSION['error'] . "</p> 
			  	</div>
  			";
        unset($_SESSION['error']);
    }
    ?>
</div>
</body>


</html>