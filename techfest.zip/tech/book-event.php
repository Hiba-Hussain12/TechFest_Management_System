<?php
session_start();
include "includes/conn.php";

if (isset($_POST['pid']) && isset($_POST['eid'])) {
    $pid = $_POST['pid'];
    $eid = $_POST['eid'];

    // Check if the user has already booked the event
    $checkBookingQuery = "SELECT * FROM booking WHERE pid = '$pid' AND eid = '$eid'";
    $checkBookingResult = $conn->query($checkBookingQuery);

    if ($checkBookingResult->num_rows > 0) {
        // The user has already booked this event
        echo '<script>alert("You have already booked this event"); window.location.href = "index.php";</script>';
        exit();
    }

    // Assuming 'booking' is your table name
    $insertQuery = "INSERT INTO booking (pid, eid) VALUES ('$pid', '$eid')";

    if (mysqli_query($conn, $insertQuery)) {
        echo '<script>alert("Event booked successfully"); window.location.href = "index.php";</script>';
        exit();
    } else {
        echo '<script>alert("Error booking event");</script>';
        exit();
    }
} else {
    // Redirect or handle the case where pid and eid are not set
    header('location: index.php');
    exit();
}
?>
