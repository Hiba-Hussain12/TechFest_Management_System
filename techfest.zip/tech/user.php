<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Techfest login</title>
    <link rel="stylesheet" href="login.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<?php
session_start();
if (isset($_SESSION['admin'])) {
    header('location: admin/dashboard.php');
}

if (isset($_SESSION['user'])) {
    header('location: index.php');
}
?>

<body>
    <div class="wrapper">
        <form action="login.php" method="post">
            <h1>Login</h1>
            <div class="input-box">
                <input type="email" placeholder="email" name="email" required><i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" placeholder="password" name="password" required><i class='bx bxs-lock-alt'></i>
            </div>
            <button type="submit" class="btn" name="login">Login</button>

            <div class="registration-link">
                <p>Don't have an account?<a href="register.php">Register</a></p>
            </div>
            <?php
            if (isset($_SESSION['error'])) {
                echo "
                <div class='callout callout-danger text-center mt20' style='padding: 10px;'>
                  <p>" . $_SESSION['error'] . "</p> 
                </div>
                ";
                unset($_SESSION['error']);
            }
            ?>
        </form>
    </div>
</body>
</html>