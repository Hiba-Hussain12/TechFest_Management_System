<?php
include 'includes/conn.php';
include 'includes/session.php';

$font = realpath('arial.ttf');


$certificateDirectory = 'certificates';
if (!is_dir($certificateDirectory)) {
    mkdir($certificateDirectory);
}

$userID = $_SESSION['user'];

$query = "
    SELECT registration.*, event.eventname,event.date
    FROM booking
    JOIN registration ON registration.id = booking.pid
    JOIN event ON event.eid = booking.eid
    WHERE booking.is_approved = 1
    AND booking.pid = $userID
";


$result = $conn->query($query);


function wrapText($text, $maxWidth, $font, $fontSize)
{
    $wrappedText = '';
    $words = explode(' ', $text);

    foreach ($words as $word) {
        $testText = $wrappedText . ' ' . $word;
        $testBox = imagettfbbox($fontSize, 0, $font, $testText);

        if ($testBox[2] > $maxWidth) {
            $wrappedText .= "\n" . $word;
        } else {
            $wrappedText .= ' ' . $word;
        }
    }

    return $wrappedText;

}

while ($participant = $result->fetch_assoc()) {
    $image = imagecreatefromjpeg("format.jpg");

    if ($image) {
        $color = imagecolorallocate($image, 255, 215, 0);
        $colors = imagecolorallocate($image, 255, 215, 215);
       
        $formattedDate = date('d F, Y', strtotime($participant['date']));

        imagettftext($image, 100, 0, 5300, 4850, $color, $font, $formattedDate);
        $participantEventname= $participant['eventname'];
        $participantName = $participant['name'];
        
        $textWidth = imagettfbbox(50, 0, $font, $participantName)[2];
        $xStart = 3850 - ($textWidth / 2);

        imagettftext($image, 300, 0, $xStart, 2800, $color, $font, $participantName);
        $description = "Has participated in the Event $participantEventname conducted on $formattedDate";
        $wrappedDescription = wrapText($description, 1800, $font, 40);
        imagettftext($image, 100, 0, 2200, 3100, $colors, $font, $wrappedDescription);

        $outputPath = "$certificateDirectory/{$participant['name']}_{$participant['eventname']}.jpg";
        $success = imagejpeg($image, $outputPath);

        if ($success) {
            echo "Certificate for {$participant['name']} in {$participant['eventname']} generated successfully. ";
            echo "<a href='$outputPath' download>Download Certificate</a><br>";
        } else {
            echo "Error creating certificate for {$participant['name']} in {$participant['eventname']}<br>";
        }

        imagedestroy($image);
    } else {
        echo "Error loading background image.<br>";
    }
}

$result->free();
$conn->close();
?>
