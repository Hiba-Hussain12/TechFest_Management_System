<?php
session_start();
include 'includes/conn.php';

if (isset($_SESSION['user'])) {
    $userId = $_SESSION['user'];

    $bookingSql = "SELECT e.*, b.bid,b.is_approved FROM event e 
                    INNER JOIN booking b ON e.eid = b.eid 
                    WHERE b.pid = $userId";

    $bookingResult = $conn->query($bookingSql);

    if ($bookingResult->num_rows > 0) {
?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="home.css">
            <title>Booked Events</title>
        </head>

        <body>
            <div class="viewbookedevent">
                <h2>Booked Events</h2>
                <div class="booked">
                    <?php
                    while ($bookingRow = $bookingResult->fetch_assoc()) {
                        $image = (!empty($bookingRow['photo'])) ? 'assets/images/' . $bookingRow['photo'] : 'assets/images/profile.jpg';
                    ?>
                        <div class="event-item">
                            <a href="bookedeventview.php?bid=<?php echo $bookingRow['bid']; ?>">
                                <img src="<?php echo $image; ?>" alt="Event Image">
                            </a>

                            <?php
                            if (isset($bookingRow['is_approved']) && $bookingRow['is_approved'] == 1) {
                            ?>
                                <form action="download_certificate.php?eid=<?php echo $bookingRow['eid']; ?>" method="post">
                                    <input type="hidden" name="eid" value="<?php echo $bookingRow['eid']; ?>">
                                    <button type="submit">Download Certificate</button>
                                </form>
                            <?php
                            }
                            ?>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </body>

        </html>
<?php
    } else {
        echo '<p>No events booked yet.</p>';
    }
} else {
    // Redirect to the login page if the user is not logged in
    header('Location: login.php');
    exit();
}
?>
