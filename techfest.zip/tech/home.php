<!DOCTYPE html>
<html lang="en">

<head>
    <title>Techfest Management</title>
    <link rel="stylesheet" type="text/css" href="home.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,300;0,700;0,800;1,300;1,400;1,600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.2/css/fontawesome.min.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <header>
        <div class="main">
            <div class="navbar">
                <h1>#TF~</h1>
                <nav class="nav1">
                    <ul>

                        <li class="links"><a href="#workshop">Workshops</a></li>
                        <li class="links"><a href="#competitions">Competitions</a></li>
                        <li class="links"><a href="#events">Events</a></li>
                        <li class="links"><a href="#sponsors">Sponsors</a></li>
                        <li class="links"><a href="#contact">Contact</a></li>

                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <div class="contentmain">
        <div class="content">
            <h1>TECH FEST</h1>
            <p>Its time to Immerse yourself in the World of Technology and unleash the inner Technical Wizardry.<br>We are planning something that would lift your spirits.<br>Do join ,and grab your oppertunity!.<br><br></p>
            <a href="index.php" class="hero-btn">LOGIN</a>
        </div>
    </div>

    <!-- Workshop -->
    <section id="workshop">
        <h2>WORKSHOPS</h2>
        <div class="container">
            <?php
            include "includes/conn.php";

            $sql = "SELECT * FROM event where type='workshop' ";
            $result = $conn->query($sql);

            if (!$result) {
                die("Invalid query!");
            }

            while ($row = $result->fetch_assoc()) {
                $image = (!empty($row['photo'])) ? 'assets/images/' . $row['photo'] : 'assets/images/profile.jpg';
                $fromtime12hr = date('h:i A', strtotime($row['fromtime']));
                $totime12hr = date('h:i A', strtotime($row['totime']));
                $formattedDate = date('d-m-Y', strtotime($row['date']));
            ?>
                <div class="item-container">
                    <div class="img-container">
                        <img src="<?php echo $image; ?>" width="270px" height="400px" alt="Event image">
                    </div>

                    <div class="body-container">
                        <div class="overlay"></div>

                        <div class="event-info">
                            <p class="title"><?php echo $row['eventname']; ?></p>
                            <div class="separator"></div>
                            <!-- <p class="price">Free</p> -->

                            <div class="additional-info">
                                <p class="info">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <?php echo $row['venue']; ?>
                                </p>
                                <p class="info">
                                    <i class="far fa-calendar-alt"></i>
                                    <?php echo $formattedDate  ?>
                                    <i class="fa-solid fa-clock"></i>
                                    <?php echo $fromtime12hr  ?>
                                </p>

                                <p class="info description">
                                    <?php echo $row['description']; ?>
                                    <!-- <span>more...</span> -->
                                </p>
                            </div>
                        </div>
                        <button class="action">Book it</button>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </section>
    <!-- competitions -->
    <section id="competitions">
        <h2>COMPETITIONS</h2>
        <div class="container">
            <?php
            include "admin\includes\conn.php";

            $sql = "SELECT * FROM event where type='competitions' ";
            $result = $conn->query($sql);
            if (!$result) {
                die("Invalid query!");
            }

            while ($row = $result->fetch_assoc()) {
                $image = (!empty($row['photo'])) ? 'assets/images/' . $row['photo'] : 'assets/images/profile.jpg';
                $fromtime12hr = date('h:i A', strtotime($row['fromtime']));
                $totime12hr = date('h:i A', strtotime($row['totime']));
                $formattedDate = date('d-m-Y', strtotime($row['date']));

            ?>
                <div class="item-container">
                    <div class="img-container">
                        <img src="<?php echo $image; ?>" width="270px" height="400px" alt="Event image">
                    </div>

                    <div class="body-container">
                        <div class="overlay"></div>

                        <div class="event-info">
                            <p class="title"><?php echo $row['eventname']; ?></p>
                            <div class="separator"></div>
                            <!-- <p class="price">Free</p> -->

                            <div class="additional-info">
                                <p class="info">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <?php echo $row['venue']; ?>
                                </p>
                                <p class="info">
                                    <i class="far fa-calendar-alt"></i>
                                    <?php echo $formattedDate  ?>
                                    <i class="fa-solid fa-clock"></i>
                                    <?php echo $fromtime12hr  ?>
                                </p>

                                <p class="info description">
                                    <?php echo $row['description']; ?>
                                    <!-- <span>more...</span> -->
                                </p>
                            </div>
                        </div>
                        <button class="action">Book it</button>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </section>
    <section id="events">
        <h2>OTHER EVENTS</h2>
        <div class="container">
            <?php
            include "admin\includes\conn.php";

            $sql = "SELECT * FROM event where type='others' ";
            $result = $conn->query($sql);

            if (!$result) {
                die("Invalid query!");
            }

            while ($row = $result->fetch_assoc()) {
                $image = (!empty($row['photo'])) ? 'assets/images/' . $row['photo'] : 'assets/images/profile.jpg';
                $fromtime12hr = date('h:i A', strtotime($row['fromtime']));
                $totime12hr = date('h:i A', strtotime($row['totime']));
                $formattedDate = date('d-m-Y', strtotime($row['date']));
            ?>
                <div class="item-container">
                    <div class="img-container">
                        <img src="<?php echo $image; ?>" width="270px" height="400px" alt="Event image">
                    </div>

                    <div class="body-container">
                        <div class="overlay"></div>

                        <div class="event-info">
                            <p class="title"><?php echo $row['eventname']; ?></p>
                            <div class="separator"></div>
                            <!-- <p class="price">Free</p> -->

                            <div class="additional-info">
                                <p class="info">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <?php echo $row['venue']; ?>
                                </p>
                                <p class="info">
                                    <i class="far fa-calendar-alt"></i>
                                    <?php echo $formattedDate  ?>
                                    <i class="fa-solid fa-clock"></i>
                                    <?php echo $fromtime12hr  ?>
                                </p>

                                <p class="info description">
                                    <?php echo $row['description']; ?>

                                </p>
                            </div>
                        </div>
                        <button class="action">Book it</button>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </section>
    <!-- sponsors -->
    <section id="sponsors">
    <h2>SPONSORS</h2>
        <div class="sponsors">
            <?php
            include "admin\includes\conn.php";

            $sql = "SELECT photo FROM sponsors ";
            $result = $conn->query($sql);

            if (!$result) {
                die("Invalid query!");
            }

            while ($row = $result->fetch_assoc()) {
                $image = (!empty($row['photo'])) ? 'assets/images/' . $row['photo'] : 'assets/images/profile.jpg';

            ?>



                <img src="<?php echo $image; ?>">

            <?php
            }
            ?>
        </div>
    </section>

    <!--footer-->
    <footer>

       <div class="footer"id="contact">
        <div class="footer-container">
            <div class="sec aboutus">
                <h2>About us</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
                    nisi ut aliquip ex ea commodo consequat. </p>
                <ul class="sci">
                    <li><a href="#"><i class='bx bxl-instagram'></i></a></li>
                    <li><a href="#"><i class='bx bxl-youtube'></i></a></li>
                    <li><a href="#"><i class='bx bxl-twitter'></i></a></li>
                    <li><a href="#"><i class='bx bxl-facebook-circle'></i></a></li>
                    <li><a href="#"><i class='bx bxl-telegram'></i></a></li>

                </ul>
            </div>
            <div class="sec quicklinks">
                <h2>Quick links</h2>
                <ul>
                    <li><a href="#">About</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Help</a></li>
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="sec footcontact">
                <h2>Contact Us</h2>
                <ul class="info">
                    <li>
                        <span><i class='bx bxs-map'></i></span>
                        <span> Mozilla Foundation 331<br>
                         E Evelyn Ave Mountain View,<br>
                            CA 94041 USA</span>
                    </li>
                    <li>
                        <span><i class='bx bxs-phone'></i></span>
                        <a href="tel:+911243567890"> +91 124 356 7890</a><br>
                        <a href="tel:+911243567890"> +91 124 356 7890</a><br>
                    </li>
                    <li>
                        <span><i class='bx bxl-gmail'></i></span>
                        <a href="mailto:abcdefghijk@gmail.com">abcdefghijk@gmail.com</a><br>
                    </li>
                </ul>
            </div>
    </footer>
    <div class="copyrighttext">
    <p> © abcdefg 2023</p>
    </div>
    </div>  
    
</body>

</html>