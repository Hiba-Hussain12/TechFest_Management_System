<!-- event-view.php -->
<?php
session_start();
include 'includes/conn.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Booked</title>
    <link rel="stylesheet" href="admin/includes/event-view.css">
</head>
<body>

<?php
if (isset($_GET['bid'])) {
    $bid = $_GET['bid'];

    $bookingSql = "SELECT e.*, b.bid FROM event e 
    INNER JOIN booking b ON e.eid = b.eid 
    WHERE b.bid = $bid";
     $bookingResult = $conn->query($bookingSql);
     if ($bookingResult->num_rows > 0) {
        while ($bookingRow = $bookingResult->fetch_assoc()) {
        $fromtime12hr = date('h:i A', strtotime($bookingRow['fromtime']));
        $totime12hr = date('h:i A', strtotime($bookingRow['totime']));
        $formattedDate = date('d-m-Y', strtotime($bookingRow['date']));
        $image = (!empty($bookingRow['photo'])) ? 'assets/images/' . $bookingRow['photo'] : 'assets/images/profile.jpg';
        // Display the event details
        echo "
            <div class='container'>
              <div class='image-container'>
                <img src='$image' alt='Event Image'>
              </div>
              <div class='content-container'>
                <h1>$bookingRow[eventname]</h1>
                <h5>Date: $formattedDate </h5>
                <h5>From: $fromtime12hr </h5>
                <h5>To: $totime12hr </h5>
                <h5>Venue: $bookingRow[venue] </h5>
                <p>Description: $bookingRow[description] </p>
              </div>
            </div>
        ";

    }
  }
}

?>

</body>
</html>
