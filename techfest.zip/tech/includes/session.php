<?php
	include 'includes/conn.php';
	session_start();

	if(isset($_SESSION['user'])){
		$sql = "SELECT * FROM registration WHERE id = '".$_SESSION['user']."'";
		$query = $conn->query($sql);
		$voter = $query->fetch_assoc();
	}
	else{
		header('location: index.php');
		exit();
	}

?>