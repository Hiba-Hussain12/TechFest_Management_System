<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="register.css" type="text/css">
    <title>Registration form</title>
</head>
<body>
    <div class="main">
        <div class="register">
            <h2>Registration</h2>
            <form id="register"action="register.php" method="post">
                <label>Name :</label>
                <input type="text" name="name" id="name" placeholder="Enter your name"required>
                <br><br>
                <label>email :</label>
                <br>                
                <input type="email" name="email" id="name" placeholder="Enter your valid email id"required>
                <br><br>
                <label>Contact no :</label>
                <input type="text" name="contact" id="name" placeholder= "Contact number"title="Error Message"pattern="[1-9]{1}[0-9]{9}" required>
                <br><br>
                <label>College :</label>
                <input type="text" name="college" id="name" placeholder="college name"required>
                <br><br>
                <label>Branch :</label>
                <input type="text" name="branch" id="name" placeholder="Branch name"required >
                <br><br>
                <label>Year :</label>
                <br>
                <input type="text" name="year" id="name" placeholder="year of study"required>
                <br><br>
                <label>password :</label>
                
                <input type="password" name="password" id="name" placeholder="password"required>
                <br><br>

                <input type="submit" value="submit" name="submit" id="submit">
            </form>
        </div>
    </div>
</body>
</html>

<?php
if (isset($_POST['submit'])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $contact = $_POST["contact"];
    $college = $_POST["college"];
    $branch = $_POST["branch"];
    $year = $_POST["year"];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
  
    $conn = new mysqli("localhost", "root", "", "techfest");

    if ($conn->connect_error) {
        die('Could not connect: ' . $conn->connect_error);
    }

    // Check if email already exists
    $sql1="alter table registration add  unique(email)";
    $sql2 = "SELECT * FROM registration WHERE email = ?";
    $stmt = $conn->prepare($sql2);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result2 = $stmt->get_result();

    if ($result2->num_rows > 0) {
        $errors[] = 'Sorry, the email address \'' . $_POST['email'] . '\' is already in use.';
        echo '<script>alert("'.$errors[0].'"); window.location.href = "/tech/register.php"; </script>';
    } else {
        // Insert new record
        $sql = "INSERT INTO registration (name,email,contact,college,branch,year,password) VALUES ('$name', '$email', '$contact', '$college', '$branch','$year','$password')";

        if ($conn->query($sql)) {
            echo '<script>alert("One recorded successfully"); window.location.href = "/tech/user.php"; </script>';
        } else {
            echo '<script>alert("Error: ' . $conn->error . '"); window.location.href = "/tech/register.php"; </script>';
        }
    }

    $stmt->close();
    $conn->close();
}
?>